#!/bin/bash

cp LinuxDaemon /usr/bin/columno
cp columno.service /etc/systemd/system/columno.service
systemctl enable columno
systemctl start columno
echo "The Columno server is now running on port 5435 with the database columnodb and supports the PostgreSQL protocol. You can connect to the server using, e.g., psql:"
echo "$ psql -p 5435 -h localhost -U <create a user on columno.com> columnodb"
