systemctl stop columno
systemctl disable columno
rm /etc/systemd/system/columno.service
rm /usr/bin/columno

