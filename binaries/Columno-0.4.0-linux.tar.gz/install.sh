#!/bin/bash

cp LinuxDaemon /usr/bin/columno
cp columno.service /etc/systemd/system/columno.service
systemctl enable columno
systemctl start columno
